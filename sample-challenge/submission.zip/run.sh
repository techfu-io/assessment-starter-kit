./fizzbuzz.sh $*
